const HAND_RANKS = {
ROYAL_FLUSH: 9, // ロイヤルフラッシュ
STRAIGHT_FLUSH: 8, // ストレートフラッシュ
FOUR_OF_A_KIND: 7, // フォーカード
FULL_HOUSE: 6, // フルハウス
FLUSH: 5, // フラッシュ
STRAIGHT: 4, // ストレート
THREE_OF_A_KIND: 3, // スリーカード
TWO_PAIR: 2, // ツーペア
ONE_PAIR: 1, // ワンペア
HIGH_CARD: 0 // ハイカード（役なし）
};
const parent =
const child =
